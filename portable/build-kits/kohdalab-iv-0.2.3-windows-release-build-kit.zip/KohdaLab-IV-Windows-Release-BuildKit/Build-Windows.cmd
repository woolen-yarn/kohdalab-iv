@echo off
setlocal
cd /d "%~dp0project"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\scripts\build_windows_portable.ps1"
set "TaskExit=%ERRORLEVEL%"
if not "%TaskExit%"=="0" goto build_failed
cd /d "%~dp0"
if not exist "Release" mkdir "Release"
copy /y "project\dist\releases\v0.2.3\windows-x64\kohdalab-iv-0.2.3-windows-x64-portable.zip" "Release\" >nul
if errorlevel 1 goto copy_failed
copy /y "project\dist\releases\v0.2.3\windows-x64\SHA256SUMS.txt" "Release\" >nul
if errorlevel 1 goto copy_failed
echo Portable ZIP and checksum are ready in Release.
start "" explorer "%~dp0Release"
exit /b 0
:copy_failed
set "TaskExit=1"
:build_failed
echo Build did not complete. See project\build\windows-portable-build.log.
pause
exit /b %TaskExit%
