KohdaLab IV 0.2.3 - Windows Release Builder

This is the build kit. Do not distribute this folder as the portable app.

1. Extract the entire ZIP on your Windows x64 build PC.
2. Double-click Build-Windows.cmd.
3. After success, the Release folder opens automatically.
4. Distribute the portable ZIP in Release. Keep SHA256SUMS.txt with it.

If uv is missing on the build PC, install it with:
  winget install --id astral-sh.uv -e
Then close the terminal and run Build-Windows.cmd again.

The user distribution has only four top-level entries:
  KohdaLab IV.exe
  README.txt
  _internal/
  support/

The macOS distribution uses the same layout, with KohdaLab IV.app and
its runtime inside the app instead of a separate _internal folder.

Users extract the whole portable ZIP and open the application.
Python, uv and VISA are not required on the instrument PC for supported
native connections. Windows driver approval can be required on first setup.

USB/GPIB communication was reported working on the Windows instrument PC.
The final portable ZIP was confirmed working by the user.

Technical build documentation and complete sources are inside project.
