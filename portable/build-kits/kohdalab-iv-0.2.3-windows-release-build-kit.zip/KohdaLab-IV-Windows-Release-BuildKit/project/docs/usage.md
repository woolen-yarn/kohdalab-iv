# KohdaLab IV Usage Guide

This guide keeps the detailed operating notes for KohdaLab IV. For first-time machine setup, see [Initial setup](initial_setup.md).

## 日本語

KohdaLab IV は、Yokogawa GS210 または Yokogawa 7651 を source、Agilent/HP 34401A、Agilent/Keysight 34411A、Keysight 34465A、または ADCMT 7461A を meter として使う DC IV/VI 測定ツールです。GUI、CLI、Jupyter Notebook から同じ測定コアを使えます。

現在の標準構成は次の通りです。

- Source: `YOKOGAWA_GS210` at `GPIB0::2::INSTR`
- Optional source: `YOKOGAWA_7651`
- Meter: `AGILENT_34401A` at `GPIB0::26::INSTR`
- Optional meter: `AGILENT_34411A`, `KEYSIGHT_34411A`, `KEYSIGHT_34465A`, `ADCMT_7461A`
- Config: packaged default or an explicit local JSON file

### 起動

GUI は VBS ランチャーから起動できます。

```text
desktop\KohdaLab_IV_GUI.vbs
```

プロジェクトディレクトリから直接起動する場合は次を使います。

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run --extra gui kohdalab-iv-gui
```

測定せずに packaged default config だけ確認する場合:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run kohdalab-iv check-config
```

実機PC用の編集可能なconfigを作る場合:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run kohdalab-iv init-config config\local.json
```

既存ファイルは上書きしません。意図的に置き換える場合だけ末尾に
`--force` を指定します。

version、採用されたconfig、scan plan、VISA resourceをまとめて診断する場合:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run kohdalab-iv --config config\local.json doctor
```

測定やsource outputは行いません。サポート用に保存する場合は末尾へ
`--json` を指定します。

Jupyter を起動する場合:

```powershell
uv run --extra notebook jupyter lab
```

### GUI 構成

GUI は 3 パネル構成です。

- 左: `Config`, `Source`, `Meter`
- 中央: `Measurement`, `Output`, `Run`, live plot
- 右: log と折りたたみ可能な最新行の `Field / Value`

`Config` は選択したローカルJSONを読み書きします。GUIの初回起動時は、編集可能な `~/.kohdalab/config/iv.json` を作成します（Windows: `%USERPROFILE%\.kohdalab\config\iv.json`）。TRKRと同じフォルダーを使い、ファイル名を分けています。最後に開いたパスは `~/.kohdalab/last_iv_config.json` に記憶します。既存の `~/.kohdalab-iv/last_config.json` も、新しい履歴がない場合に読み込みます。`KOHDALAB_IV_STATE_DIR`、または共通の `KOHDALAB_STATE_DIR` で保存先のルートを変更できます。

`Measurement` の `Step` 下にある `Timing / Compliance…` を押すと、`Wait time`、`Average count`、`Compliance`（コンプライアンス）をまとめて編集できます。`OK` で適用し、`Cancel` または閉じるボタンで変更を取り消します。`Current limit (V source)` は電圧印加時の電流停止しきい値（初期値 **1 mA**）、`Voltage limit (I source)` は電流印加時の電圧停止しきい値（初期値 **1 V**）です。両方の値と単位を入力して `Config` の `Save` を押すと保存され、モードを切り替えても保持されます。既存ファイルの `compliance` 値は引き継ぎます。

各測定点の平均値について、絶対値がしきい値以上なら測定を停止し、出力をゼロへ戻してOFFにします。連続的なハードウェア遮断ではありません。機器への保護設定は機器仕様の範囲へ補正されるため、例えば7651の電流停止しきい値を1 mAにしても、機器の電流保護設定は5 mAになります。

保存先は `measurements.iv.safety.current_compliance` と `voltage_compliance` です。`compliance` にも保存時のモードの値を記録します。APIはモードに対応する専用フィールドを優先し、ない場合に従来の `compliance` を使います。

`Source` は GS210 または 7651 を選択できます。7651 は GS210 の SCPI ではなく、`F`/`R`/`S`/`O` 系の旧コマンドで制御します。`Meter` では 34401A、34411A、34465A、7461A を選択でき、DMM の積分条件として `NPLC` を設定します。
ADCMT 7461A は `command_language` で SCPI/ADC を切り替えられます。標準 config は `scpi` です。GPIB では SCPI 設定を送ってから `READ?` で読みます。USB では 7461A を ADC コマンド系として扱い、`F1`/`F5`、`R0`、`ITP<nplc>` で設定してから output data を読みます。

`Measurement` では sweep 形状と各点の測定条件を設定します。

- `Mode`: `I-V` は電流を流して電圧を測定、`V-I` は電圧をかけて電流を測定
- `Sweep`: `linear`, `round_trip`, `zero_centered`, `custom_list`
- `Start`, `End`, `Step`: unit 付き
- `Wait time`
- `Average count`

config の `timing.start_settle_s` は、start 到達後の最初の読み出し前だけ追加で待つ時間です。標準値は 0.5 s です。

ADCMT 7461A では、`Wait time` 後の最初の 1 reading を捨ててから採用値を読みます。source 変更直後の過渡値を拾いにくくするためです。

plot は sweep している量を x 軸にします。source target が増える点は `forward`、減る点は `backward` として別色で表示します。抵抗は実測の電圧と電流から計算し、`mOhm`, `Ohm`, `kOhm`, `MOhm` などの読みやすい単位で表示します。コンダクタンスも `mS`, `uS`, `nS` などで表示します。

### 安全動作

通常終了と Stop:

1. Source を 0 に ramp します。
2. Source output を off にします。
3. 装置は connected/remote のまま残し、GUI から次の操作を続けられるようにします。

sweep 中は config load/save、source/meter connect/disconnect、resource refresh、
手動 Output Off を無効化します。測定を止めるときは Stop を使い、測定スレッド側で
zero ramp と output off を順番に実行します。

All Disconnect、Source Disconnect、アプリ終了:

1. Source output off と level zero を試します。
2. 装置を local に戻します。
3. VISA resource を close します。

測定エラー時は、まず source output off を優先します。

### Config

リポジトリ開発時の標準configは次です。

```text
src/kohdalab_iv/resources/default.json
```

config formatは `"config_version": 1` で管理します。fieldがない旧configはversion 1へ自動補完され、未対応の将来versionは装置接続前に拒否されます。JSON Schemaは `src/kohdalab_iv/resources/config.schema.json` にあります。

実機PC固有のresourceと安全値は `init-config` で作ったローカルJSONへ設定します。測定値はengineering unitで書けます。

- Voltage: `nV`, `uV`, `mV`, `V`
- Current: `pA`, `nA`, `uA`, `mA`, `A`

内部の scan plan と CSV は、解析しやすいように SI 単位の値を使います。

### CSV

CSV は測定中に 1 点ずつ書き込まれるので、途中で Stop してもそこまでのデータが残ります。出力先とファイル名は GUI の Output パネル、またはactive configの `measurements.iv.output` で設定します。

主な出力項目:

- timestamp と elapsed time
- point number と direction
- target value と unit
- 読み取った `voltage_V/current_A`
- `resistance_Ohm/conductance_S`

詳細仕様は [iv_measurement_spec.md](iv_measurement_spec.md) を参照してください。

---

## English

KohdaLab IV is a DC IV/VI measurement tool for a lab setup using a Yokogawa
GS210 or Yokogawa 7651 as the source and an Agilent/HP 34401A,
Agilent/Keysight 34411A, Keysight 34465A, or ADCMT 7461A as the meter.
The same measurement core is available from the GUI, CLI, and Jupyter notebooks.

The current standard hardware profile is:

- Source: `YOKOGAWA_GS210` at `GPIB0::2::INSTR`
- Optional source: `YOKOGAWA_7651`
- Meter: `AGILENT_34401A` at `GPIB0::26::INSTR`
- Config: packaged default or an explicit local JSON file

### Quick Start

Launch the GUI from the desktop VBS launcher:

```text
desktop\KohdaLab_IV_GUI.vbs
```

The VBS launcher follows the TRKR launcher style: it hides the command window,
runs from the project directory, and writes launcher output to `gui_launcher.log`.

Keep the VBS file in the repository and place a shortcut to it on the Windows
desktop. The launcher resolves the project root from its repository location.

Or launch it from the project directory:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run --extra gui kohdalab-iv-gui
```

Check the packaged default without running a measurement:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run kohdalab-iv check-config
```

Create an editable config for the instrument PC:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run kohdalab-iv init-config config\local.json
```

The command refuses to replace an existing file. Add `--force` only when the
existing destination should intentionally be replaced.

Report the installed version:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run kohdalab-iv --version
```

Collect config, scan-plan, runtime, and VISA diagnostics without measuring:

```powershell
& "$env:USERPROFILE\.local\bin\uv.exe" run kohdalab-iv --config config\local.json doctor --json
```

Start Jupyter:

```powershell
uv run --extra notebook jupyter lab
```

### GUI Layout

The GUI uses a three-panel layout.

- Left: `Config`, `Source`, `Meter`
- Center: `Measurement`, `Output`, `Run`, and the live plot
- Right: log and collapsible latest-row `Field / Value`

`Config` loads and saves the selected local JSON file. On first GUI launch,
an editable default is created at `~/.kohdalab/config/iv.json`
(`%USERPROFILE%\.kohdalab\config\iv.json` on Windows), alongside TRKR configs
with a separate filename. The last path is stored in `~/.kohdalab/last_iv_config.json`;
the old `~/.kohdalab-iv/last_config.json` remains a fallback. Override the state
root with `KOHDALAB_IV_STATE_DIR` or the shared `KOHDALAB_STATE_DIR`.

Click **Timing / Compliance…** below **Step** in Measurement to edit Wait time, Average count, and Compliance. **OK** applies changes; **Cancel** or closing the popup discards them. Set `Current limit (V source)` (default **1 mA**)
and `Voltage limit (I source)` (default **1 V**), then click Config **Save**. Both values and
units survive mode changes and reloads; existing legacy `compliance` values
are preserved. They are saved as `measurements.iv.safety.current_compliance`
and `voltage_compliance`, with the active value also written to `compliance`.
The API prefers the mode-specific field, falling back to legacy `compliance`.

After each averaged reading, reaching or exceeding the absolute threshold
stops the sweep and ramps the output to zero before turning it off. This is
a software check, not continuous hardware shutdown. Hardware protection is
clamped to the instrument's supported range: for example, the 7651 receives
a 5 mA hardware setting even when the software threshold is 1 mA.

`Source` selects GS210 or 7651. `Meter` selects 34401A, 34411A, 34465A, or 7461A and exposes
the DMM integration setting, `NPLC`.
The Yokogawa 7651 driver uses the legacy `F`/`R`/`S`/`O` commands rather than
GS210 SCPI commands.
The ADCMT 7461A command set is selected with `command_language`. The standard
config uses `scpi`. Over GPIB, SCPI setup is sent before readings are taken
with `READ?`. Over USB, the driver treats the 7461A as an ADC-command device:
it configures with `F1`/`F5`, `R0`, and `ITP<nplc>`, then reads output data.

`Measurement` owns the sweep shape and point timing.

- `Mode`: `I-V` sources current and measures voltage; `V-I` sources voltage and
  measures current
- `Sweep`: `linear`, `round_trip`, `zero_centered`, or `custom_list`
- `Start`, `End`, `Step` with units
- `Wait time`
- `Average count`

Config `timing.start_settle_s` is the extra delay after the source reaches the
start point and before the first read. The standard value is 0.5 s.

For the ADCMT 7461A, the first reading after `Wait time` is discarded before the accepted value is read. This avoids using a transient value after the source target changes.

The plot uses the swept quantity on the x-axis. Points where the source target
increases are `forward`; points where it decreases are `backward`. They are
drawn in different colors. Resistance is calculated from the measured
voltage/current values and displayed with readable units such as `mOhm`, `Ohm`,
`kOhm`, and `MOhm`. Conductance is also shown above the plot with readable units
such as `mS`, `uS`, and `nS`.

### Safety Behavior

Normal finish and Stop:

1. Ramp the source back to zero.
2. Turn source output off.
3. Keep instruments connected and remote so the GUI can continue.

During an active sweep, config load/save, source/meter connect or disconnect,
resource refresh, and manual Output Off are disabled. Use Stop to end the sweep
so the measurement thread can ramp to zero and release control in order.

All Disconnect, Source Disconnect, or app close:

1. Try source output off and level zero.
2. Return instruments to local.
3. Close the VISA resources.

On measurement error, source output off is the first priority.

### Config

The repository-development copy of the packaged default is:

```text
src/kohdalab_iv/resources/default.json
```

The format is versioned with `"config_version": 1`. Legacy configs without the field are normalized to version 1, while unsupported future versions fail before hardware access. The JSON Schema is `src/kohdalab_iv/resources/config.schema.json`.

Use `init-config` to create a local copy for machine-specific resources and safety values.
Measurement values can be written with engineering units.

- Voltage: `nV`, `uV`, `mV`, `V`
- Current: `pA`, `nA`, `uA`, `mA`, `A`

Internally, scan plans and CSV files use SI values for analysis consistency.

### CSV

Rows are written continuously during measurement, so partial data remains when a
run is stopped. Output settings are controlled by the GUI Output panel or
`measurements.iv.output` in the active config.

Key output fields:

- timestamp and elapsed time
- point number and direction
- target value and unit
- read `voltage_V/current_A`
- `resistance_Ohm/conductance_S`

See [iv_measurement_spec.md](iv_measurement_spec.md) for the full
implementation specification.

### Safety

Read [SAFETY.md](../SAFETY.md) before operating real instruments. Always confirm
source mode, limits, compliance, wiring, and a manual way to disable output.

### Windows Setup

Use [windows_setup.md](windows_setup.md) when preparing a Windows
instrument PC.

### Citation

If you use this software in research, see [CITATION.cff](../CITATION.cff).

### License

This project is released under the MIT License. See [LICENSE](../LICENSE).
