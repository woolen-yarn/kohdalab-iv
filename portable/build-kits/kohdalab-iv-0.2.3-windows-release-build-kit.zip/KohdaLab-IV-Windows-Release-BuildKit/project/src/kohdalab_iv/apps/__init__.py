"""GUI applications."""
