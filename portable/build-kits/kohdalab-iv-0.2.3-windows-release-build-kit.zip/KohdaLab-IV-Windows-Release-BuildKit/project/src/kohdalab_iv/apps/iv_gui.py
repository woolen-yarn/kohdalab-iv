from __future__ import annotations

import copy
import math
import sys
from pathlib import Path
from typing import Any, Callable

from kohdalab_iv import __version__
from kohdalab_iv.api.config import (
    DEFAULT_CONFIG_PATH,
    load_config,
    managed_default_config_path,
    output_path,
    resolve_config_path,
    save_config,
    write_last_config_path,
)
from kohdalab_iv.api.experiment import Experiment
from kohdalab_iv.api.formatting import format_conductance, format_resistance
from kohdalab_iv.api.scan_plan import iv_plan_from_config
from kohdalab_iv.api.units import normalize_unit, parse_quantity
from kohdalab_iv.apps.gui_state import MeasurementRunState
from kohdalab_iv.interfaces.common import DISCOVERY_PROGRESS, list_visa_resources


SOURCE_MODELS = ["YOKOGAWA_GS210", "YOKOGAWA_7651", "SIMULATED_SOURCE"]
METER_MODELS = [
    "AGILENT_34401A",
    "AGILENT_34411A",
    "KEYSIGHT_34411A",
    "KEYSIGHT_34465A",
    "ADCMT_7461A",
    "SIMULATED_METER",
]
SOURCE_MODEL_KEYS = {
    "YOKOGAWA_GS210": "gs210",
    "YOKOGAWA_7651": "yokogawa_7651",
    "SIMULATED_SOURCE": "simulated_source",
}
METER_MODEL_KEYS = {
    "AGILENT_34401A": "dmm_34401a",
    "AGILENT_34411A": "dmm_agilent_34411a",
    "KEYSIGHT_34411A": "dmm_34411a",
    "KEYSIGHT_34465A": "dmm_34465a",
    "ADCMT_7461A": "dmm_7461a",
    "SIMULATED_METER": "simulated_meter",
}
CURRENT_UNITS = ["pA", "nA", "uA", "mA", "A"]
VOLTAGE_UNITS = ["nV", "uV", "mV", "V"]
MODE_LABELS = {
    "dc_vi": "I-V (source I, measure V)",
    "dc_iv": "V-I (source V, measure I)",
}
SNAPSHOT_FIELDS = [
    "timestamp",
    "elapsed_s",
    "point_index",
    "total_points",
    "direction",
    "source_target_value",
    "source_target_unit",
    "source_readback_value",
    "source_readback_unit",
    "voltage_V",
    "voltage_origin",
    "current_A",
    "current_origin",
    "resistance_Ohm",
    "conductance_S",
]
MODEL_KEY_MAPS = {
    "source": SOURCE_MODEL_KEYS,
    "meter": METER_MODEL_KEYS,
}


def _window_title() -> str:
    return f"KohdaLab IV v{__version__}"


def _model_config_for_selection(
    config: dict[str, Any], kind: str, model: str
) -> tuple[str | None, dict[str, Any] | None]:
    model = str(model).strip().upper()
    devices = config.get("instruments", {}).get(kind, {})
    if not isinstance(devices, dict):
        return None, None

    canonical_key = MODEL_KEY_MAPS.get(kind, {}).get(model)
    if canonical_key in devices and isinstance(devices[canonical_key], dict):
        return canonical_key, devices[canonical_key]

    for key, cfg in devices.items():
        if isinstance(cfg, dict) and str(cfg.get("model", "")).strip().upper() == model:
            return str(key), cfg
    return None, None


def _device_key_for_selection(
    config: dict[str, Any], kind: str, model: str, current_key: str
) -> str:
    key, _ = _model_config_for_selection(config, kind, model)
    return key or current_key


def _set_quantity(target: dict[str, Any], key: str, value: float, unit: str) -> None:
    target[key] = {"value": float(value), "unit": unit}


def _quantity_value(
    data: dict[str, Any], key: str, default_value: float, default_unit: str
) -> tuple[float, str]:
    value = data.get(key, {})
    if isinstance(value, dict):
        return float(value.get("value", default_value)), str(
            value.get("unit", default_unit)
        )
    return float(value), default_unit


def _short(value: Any, unit: str = "") -> str:
    if value is None:
        return "-"
    if isinstance(value, float):
        suffix = f" {unit}" if unit else ""
        return f"{value:.6g}{suffix}"
    return str(value)


def _unit_family(unit: str) -> str | None:
    key = normalize_unit(unit)
    if key in {normalize_unit(item) for item in CURRENT_UNITS} | {"microa"}:
        return "current"
    if key in {normalize_unit(item) for item in VOLTAGE_UNITS} | {"microv"}:
        return "voltage"
    return None


def _resistance_from_rows(rows: list[dict[str, Any]]) -> float | None:
    pairs = [
        (float(row["measured_A"]), float(row["measured_V"]))
        for row in rows
        if row.get("measured_A") is not None and row.get("measured_V") is not None
    ]
    if len(pairs) < 2:
        return None
    mean_i = sum(i for i, _ in pairs) / len(pairs)
    mean_v = sum(v for _, v in pairs) / len(pairs)
    denominator = sum((i - mean_i) ** 2 for i, _ in pairs)
    if denominator == 0:
        return None
    return sum((i - mean_i) * (v - mean_v) for i, v in pairs) / denominator


def main(*, startup: Callable[[Any], None] | None = None) -> None:
    from PySide6 import QtCore, QtWidgets
    import pyqtgraph as pg

    pg.setConfigOption("background", "#050505")
    pg.setConfigOption("foreground", "#e8e8e8")

    class PopupComboBox(QtWidgets.QComboBox):
        def __init__(self):
            super().__init__()
            view = QtWidgets.QListView()
            view.setTextElideMode(QtCore.Qt.TextElideMode.ElideNone)
            self.setView(view)

        def showPopup(self) -> None:
            metrics = self.view().fontMetrics()
            text_width = max(
                (
                    metrics.horizontalAdvance(self.itemText(i))
                    for i in range(self.count())
                ),
                default=0,
            )
            # Resource names may be much longer than the closed input field.
            self.view().setMinimumWidth(max(self.width(), text_width + 48))
            super().showPopup()

    class ComplianceSpinBox(QtWidgets.QDoubleSpinBox):
        def textFromValue(self, value: float) -> str:
            return f"{value:.12f}".rstrip("0").rstrip(".")

    class MeasurementWorker(QtCore.QObject):
        point_ready = QtCore.Signal(object)
        status_changed = QtCore.Signal(str)
        error_occurred = QtCore.Signal(str)
        finished = QtCore.Signal(object)

        def __init__(
            self,
            *,
            experiment: Experiment,
            config: dict[str, Any],
            output: str | None = None,
        ):
            super().__init__()
            self.experiment = experiment
            self.config = config
            self.output = output
            self._running = True

        def stop(self) -> None:
            self._running = False

        def should_continue(self) -> bool:
            return self._running

        @QtCore.Slot()
        def run(self) -> None:
            rows = []
            try:
                plan = iv_plan_from_config(self.config)
                rows = self.experiment.run_iv(
                    plan=plan,
                    output=self.output,
                    on_point=self.point_ready.emit,
                    on_status=self.status_changed.emit,
                    should_continue=self.should_continue,
                )
            except Exception as e:
                self.error_occurred.emit(str(e))
            finally:
                self.finished.emit(rows)

    class ResourceDiscoveryWorker(QtCore.QObject):
        progress = QtCore.Signal(str)
        discovered = QtCore.Signal(object)
        error_occurred = QtCore.Signal(str)
        finished = QtCore.Signal()

        @QtCore.Slot()
        def run(self) -> None:
            token = DISCOVERY_PROGRESS.set(self.progress.emit)
            try:
                self.discovered.emit(list_visa_resources())
            except Exception as error:
                self.error_occurred.emit(str(error))
            finally:
                DISCOVERY_PROGRESS.reset(token)
                self.finished.emit()

    class IVGui(QtWidgets.QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle(_window_title())
            self._apply_dark_theme()
            config_resolution = resolve_config_path()
            self.config_path = config_resolution.path
            if self.config_path is None:
                raise FileNotFoundError(
                    "The packaged default configuration could not be found."
                )
            if self.config_path.resolve() == DEFAULT_CONFIG_PATH.resolve():
                self.config_path = managed_default_config_path()
            self.config = load_config(self.config_path)
            write_last_config_path(self.config_path)
            self.experiment = Experiment(self.config, auto_connect=False)
            self.worker_thread: QtCore.QThread | None = None
            self.worker: MeasurementWorker | None = None
            self.discovery_thread: QtCore.QThread | None = None
            self.discovery_worker: ResourceDiscoveryWorker | None = None
            self.discovery_phase = "Checking connected instruments"
            self.discovery_elapsed = QtCore.QElapsedTimer()
            self.discovery_timer = QtCore.QTimer(self)
            self.discovery_timer.timeout.connect(self._update_discovery_status)
            self.rows: list[dict[str, Any]] = []
            self.startup_busy = False
            self.measurement_state = MeasurementRunState()
            self._build_widgets()
            self._build_measurement_settings_dialog()
            self._build_layout()
            self._load_fields()
            self.append_log("Ready.")

        def _build_widgets(self) -> None:
            self.config_path_edit = QtWidgets.QLineEdit(str(self.config_path))
            self.browse_button = QtWidgets.QPushButton("Browse")
            self.load_button = QtWidgets.QPushButton("Load")
            self.save_button = QtWidgets.QPushButton("Save")
            self.connect_all_button = QtWidgets.QPushButton("All Connect")
            self.disconnect_all_button = QtWidgets.QPushButton("All Disconnect")
            self.browse_button.clicked.connect(self.browse_config)
            self.load_button.clicked.connect(self.load_config)
            self.save_button.clicked.connect(self.save_config)
            self.connect_all_button.clicked.connect(self.connect_all)
            self.disconnect_all_button.clicked.connect(self.disconnect_all)

            self.source_model_combo = PopupComboBox()
            self.source_model_combo.addItems(SOURCE_MODELS)
            self.source_model_combo.currentTextChanged.connect(
                self._source_model_changed
            )
            self.source_resource_combo = PopupComboBox()
            self.source_resource_combo.setEditable(True)
            self.source_refresh_button = QtWidgets.QPushButton("Refresh")
            self.source_connect_button = QtWidgets.QPushButton("Connect")
            self.source_disconnect_button = QtWidgets.QPushButton("Disconnect")
            self.source_status = QtWidgets.QLabel("-")
            self.source_status.setWordWrap(True)
            self.source_refresh_button.clicked.connect(self.refresh_resources)
            self.source_connect_button.clicked.connect(self.connect_source)
            self.source_disconnect_button.clicked.connect(self.disconnect_source)

            self.meter_model_combo = PopupComboBox()
            self.meter_model_combo.addItems(METER_MODELS)
            self.meter_model_combo.currentTextChanged.connect(self._meter_model_changed)
            self.meter_resource_combo = PopupComboBox()
            self.meter_resource_combo.setEditable(True)
            self.nplc_spin = self._spin(0.001, 100.0, 3, 1.0)
            self.meter_refresh_button = QtWidgets.QPushButton("Refresh")
            self.meter_connect_button = QtWidgets.QPushButton("Connect")
            self.meter_disconnect_button = QtWidgets.QPushButton("Disconnect")
            self.meter_status = QtWidgets.QLabel("-")
            self.meter_status.setWordWrap(True)
            self.meter_refresh_button.clicked.connect(self.refresh_resources)
            self.meter_connect_button.clicked.connect(self.connect_meter)
            self.meter_disconnect_button.clicked.connect(self.disconnect_meter)

            self.mode_combo = PopupComboBox()
            for mode, label in MODE_LABELS.items():
                self.mode_combo.addItem(label, mode)
            self.mode_combo.currentIndexChanged.connect(self._mode_changed)
            self.sweep_combo = PopupComboBox()
            self.sweep_combo.addItems(
                ["linear", "round_trip", "zero_centered", "custom_list"]
            )
            self.start_spin = self._spin(-1e12, 1e12, 6, 0.0)
            self.end_spin = self._spin(-1e12, 1e12, 6, 0.0)
            self.step_spin = self._spin(-1e12, 1e12, 6, 1.0)
            self.start_unit_combo = PopupComboBox()
            self.end_unit_combo = PopupComboBox()
            self.step_unit_combo = PopupComboBox()
            self.wait_spin = self._spin(0.0, 3600.0, 3, 0.2)
            self.current_compliance_spin = ComplianceSpinBox()
            self.current_compliance_unit = PopupComboBox()
            self.current_compliance_unit.addItems(CURRENT_UNITS)
            self.current_compliance_unit.setCurrentText("mA")
            self.voltage_compliance_spin = ComplianceSpinBox()
            self.voltage_compliance_unit = PopupComboBox()
            self.voltage_compliance_unit.addItems(VOLTAGE_UNITS)
            self.voltage_compliance_unit.setCurrentText("V")
            for spin in (self.current_compliance_spin, self.voltage_compliance_spin):
                spin.setDecimals(12)
                spin.setRange(1e-12, 1e12)
                spin.setValue(1.0)
                spin.setKeyboardTracking(False)
                spin.setButtonSymbols(
                    QtWidgets.QAbstractSpinBox.ButtonSymbols.NoButtons
                )
            self.current_compliance_spin.setToolTip(
                "V source: stop after a reading with |I| at or above this limit."
            )
            self.voltage_compliance_spin.setToolTip(
                "I source: stop after a reading with |V| at or above this limit."
            )
            self.average_count_spin = QtWidgets.QSpinBox()
            self.average_count_spin.setRange(1, 1000)
            self.average_count_spin.setValue(1)
            self.average_count_spin.setButtonSymbols(
                QtWidgets.QAbstractSpinBox.ButtonSymbols.NoButtons
            )
            self.measurement_settings_button = QtWidgets.QPushButton(
                "Timing / Compliance…"
            )
            self.measurement_settings_button.clicked.connect(
                self.open_measurement_settings
            )
            self.check_button = QtWidgets.QPushButton("Check")
            self.start_button = QtWidgets.QPushButton("Start")
            self.stop_button = QtWidgets.QPushButton("Stop")
            self.output_off_button = QtWidgets.QPushButton("Output Off")
            self.stop_button.setEnabled(False)
            self.check_button.clicked.connect(self.check_plan)
            self.start_button.clicked.connect(self.start_measurement)
            self.stop_button.clicked.connect(self.stop_measurement)
            self.output_off_button.clicked.connect(self.output_off)
            self.status_label = QtWidgets.QLabel("idle")
            self.status_label.setWordWrap(True)
            self.step_label = QtWidgets.QLabel("-")
            self.resistance_label = QtWidgets.QLabel("-")
            self.conductance_label = QtWidgets.QLabel("-")

            self.output_dir_edit = QtWidgets.QLineEdit("results")
            self.output_browse_button = QtWidgets.QPushButton("Browse")
            self.output_name_edit = QtWidgets.QLineEdit("iv_run")
            self.auto_suffix_check = QtWidgets.QCheckBox("Auto suffix")
            self.auto_suffix_check.setChecked(True)
            output_side_width = 104
            self.output_browse_button.setFixedWidth(output_side_width)
            self.auto_suffix_check.setFixedWidth(output_side_width)
            self.output_browse_button.clicked.connect(self.browse_output_dir)

            self.plot = pg.PlotWidget()
            self.plot.setBackground("#050505")
            self.plot.setMinimumHeight(320)
            self.plot.showGrid(x=True, y=True, alpha=0.25)
            self.plot_curves = {
                "forward": self.plot.plot(
                    pen=pg.mkPen("#5aa9ff", width=2),
                    symbol="o",
                    symbolSize=5,
                    symbolBrush="#5aa9ff",
                    symbolPen="#5aa9ff",
                ),
                "backward": self.plot.plot(
                    pen=pg.mkPen("#ff9f43", width=2),
                    symbol="o",
                    symbolSize=5,
                    symbolBrush="#ff9f43",
                    symbolPen="#ff9f43",
                ),
                "custom": self.plot.plot(
                    pen=pg.mkPen("#c5a3ff", width=2),
                    symbol="o",
                    symbolSize=5,
                    symbolBrush="#c5a3ff",
                    symbolPen="#c5a3ff",
                ),
            }
            self.step_text = None
            self.resistance_text = None

            self.log = QtWidgets.QPlainTextEdit()
            self.log.setReadOnly(True)
            self.log.setMinimumHeight(216)
            self.snapshot_toggle = QtWidgets.QToolButton()
            self.snapshot_toggle.setText("Field / Value")
            self.snapshot_toggle.setCheckable(True)
            self.snapshot_toggle.setChecked(True)
            self.snapshot_toggle.setToolButtonStyle(
                QtCore.Qt.ToolButtonStyle.ToolButtonTextBesideIcon
            )
            self.snapshot_toggle.clicked.connect(self._toggle_snapshot)
            self.snapshot_table = QtWidgets.QTableWidget(0, 2)
            self.snapshot_table.setHorizontalHeaderLabels(["Field", "Value"])
            self.snapshot_table.verticalHeader().setVisible(False)
            self.snapshot_table.horizontalHeader().setStretchLastSection(True)
            self.snapshot_table.setEditTriggers(
                QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers
            )
            self.snapshot_table.setSelectionMode(
                QtWidgets.QAbstractItemView.SelectionMode.NoSelection
            )

            self.left_panel_toggle = self._side_panel_toggle(
                "<", self._toggle_left_panel
            )
            self.right_panel_toggle = self._side_panel_toggle(
                ">", self._toggle_right_panel
            )

        def _side_panel_toggle(self, text: str, slot) -> QtWidgets.QToolButton:
            button = QtWidgets.QToolButton()
            button.setText(text)
            button.setCheckable(True)
            button.setToolButtonStyle(QtCore.Qt.ToolButtonStyle.ToolButtonTextOnly)
            button.setFixedWidth(24)
            button.setSizePolicy(
                QtWidgets.QSizePolicy.Policy.Fixed,
                QtWidgets.QSizePolicy.Policy.Expanding,
            )
            button.clicked.connect(slot)
            return button

        def _apply_dark_theme(self) -> None:
            self.setStyleSheet(
                """
                QWidget {
                    background: #050505;
                    color: #e8e8e8;
                    font-size: 9pt;
                }
                QGroupBox {
                    border: 1px solid #333;
                    border-radius: 4px;
                    margin-top: 14px;
                    padding: 8px;
                    background: #0b0b0b;
                }
                QGroupBox::title {
                    subcontrol-origin: margin;
                    left: 8px;
                    padding: 0 4px;
                    color: #f0f0f0;
                }
                QLineEdit, QComboBox, QDoubleSpinBox, QSpinBox, QPlainTextEdit, QTableWidget {
                    background: #111;
                    border: 1px solid #3a3a3a;
                    border-radius: 3px;
                    color: #f2f2f2;
                    selection-background-color: #255d8f;
                }
                QPushButton, QToolButton {
                    background: #1b1b1b;
                    border: 1px solid #4a4a4a;
                    border-radius: 3px;
                    color: #f0f0f0;
                    padding: 4px 8px;
                }
                QPushButton:hover, QToolButton:hover {
                    background: #2a2a2a;
                }
                QPushButton:disabled {
                    color: #777;
                    background: #121212;
                }
                QHeaderView::section {
                    background: #151515;
                    color: #e8e8e8;
                    border: 1px solid #333;
                }
                QScrollArea {
                    border: none;
                }
                """
            )

        def _build_layout(self) -> None:
            central = QtWidgets.QWidget()
            self.setCentralWidget(central)
            root = QtWidgets.QHBoxLayout(central)
            root.setContentsMargins(8, 8, 8, 8)
            root.setSpacing(8)

            left_widget = QtWidgets.QWidget()
            left = QtWidgets.QVBoxLayout(left_widget)
            left.setSpacing(8)
            left.addWidget(self._config_group())
            left.addWidget(self._source_group())
            left.addWidget(self._meter_group())
            left.addStretch(1)
            self.left_content = QtWidgets.QScrollArea()
            self.left_content.setWidgetResizable(True)
            self.left_content.setHorizontalScrollBarPolicy(
                QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff
            )
            self.left_content.setWidget(left_widget)
            self.left_content.setMinimumWidth(260)
            self.left_content.setMaximumWidth(290)

            self.left_panel = QtWidgets.QWidget()
            left_shell = QtWidgets.QHBoxLayout(self.left_panel)
            left_shell.setContentsMargins(0, 0, 0, 0)
            left_shell.setSpacing(4)
            left_shell.addWidget(self.left_content, 1)
            left_shell.addWidget(self.left_panel_toggle)

            center_widget = QtWidgets.QWidget()
            center = QtWidgets.QVBoxLayout(center_widget)
            center.setSpacing(8)
            center.addWidget(self._measurement_group(), 0)
            center.addWidget(self._plot_status_bar(), 0)
            center.addWidget(self.plot, 1)

            self.right_panel = QtWidgets.QWidget()
            right_shell = QtWidgets.QHBoxLayout(self.right_panel)
            right_shell.setContentsMargins(0, 0, 0, 0)
            right_shell.setSpacing(4)
            right_shell.addWidget(self.right_panel_toggle)
            self.right_content = QtWidgets.QWidget()
            right = QtWidgets.QVBoxLayout(self.right_content)
            right.setSpacing(8)
            right.addWidget(self.log, 0)
            right.addWidget(self.snapshot_toggle, 0)
            right.addWidget(self.snapshot_table, 1)
            right_shell.addWidget(self.right_content, 1)

            root.addWidget(self.left_panel, 0)
            root.addWidget(center_widget, 1)
            root.addWidget(self.right_panel, 0)
            self.resize(1240, 760)

        def _config_group(self):
            group = QtWidgets.QGroupBox("Config")
            layout = QtWidgets.QVBoxLayout(group)
            row1 = QtWidgets.QHBoxLayout()
            row1.addWidget(self.config_path_edit, 1)
            row1.addWidget(self.browse_button)
            row2 = QtWidgets.QHBoxLayout()
            for button in (self.load_button, self.save_button):
                row2.addWidget(button)
            row3 = QtWidgets.QHBoxLayout()
            for button in (self.connect_all_button, self.disconnect_all_button):
                row3.addWidget(button)
            layout.addLayout(row1)
            layout.addLayout(row2)
            layout.addLayout(row3)
            return group

        def _source_group(self):
            group = QtWidgets.QGroupBox("Source")
            form = QtWidgets.QFormLayout(group)
            form.addRow("Device", self.source_model_combo)
            form.addRow(
                "Resource",
                self._resource_row(
                    self.source_resource_combo, self.source_refresh_button
                ),
            )
            buttons = QtWidgets.QHBoxLayout()
            for button in (self.source_connect_button, self.source_disconnect_button):
                buttons.addWidget(button)
            form.addRow("", buttons)
            return group

        def _compliance_group(self):
            group = QtWidgets.QGroupBox("Compliance")
            form = QtWidgets.QFormLayout(group)
            form.setVerticalSpacing(8)
            form.addRow(QtWidgets.QLabel("Current limit (V source)"))
            form.addRow(
                self._quantity_row(
                    self.current_compliance_spin, self.current_compliance_unit
                )
            )
            form.addRow(QtWidgets.QLabel("Voltage limit (I source)"))
            form.addRow(
                self._quantity_row(
                    self.voltage_compliance_spin, self.voltage_compliance_unit
                )
            )
            note = QtWidgets.QLabel(
                "Stop when |measured value| ≥ limit.\n"
                "Applied after each averaged reading."
            )
            note.setToolTip(
                "Hardware protection is limited to the instrument's supported range."
            )
            note.setWordWrap(True)
            form.addRow(note)
            return group

        def _build_measurement_settings_dialog(self) -> None:
            self.measurement_settings_dialog = QtWidgets.QDialog(self)
            self.measurement_settings_dialog.setWindowTitle("Timing / Compliance")
            layout = QtWidgets.QVBoxLayout(self.measurement_settings_dialog)
            timing = QtWidgets.QGroupBox("Timing")
            form = QtWidgets.QFormLayout(timing)
            form.addRow("Wait time (s)", self.wait_spin)
            form.addRow("Average count", self.average_count_spin)
            layout.addWidget(timing)
            layout.addWidget(self._compliance_group())
            note = QtWidgets.QLabel(
                "Use Config → Save to save these settings to the file."
            )
            note.setWordWrap(True)
            layout.addWidget(note)
            buttons = QtWidgets.QDialogButtonBox(
                QtWidgets.QDialogButtonBox.StandardButton.Ok
                | QtWidgets.QDialogButtonBox.StandardButton.Cancel
            )
            buttons.accepted.connect(self.measurement_settings_dialog.accept)
            buttons.rejected.connect(self.measurement_settings_dialog.reject)
            layout.addWidget(buttons)
            self.measurement_settings_dialog.setMinimumWidth(360)

        def open_measurement_settings(self) -> None:
            if not self._ensure_measurement_idle("Measurement Settings"):
                return
            spins = (
                self.wait_spin,
                self.current_compliance_spin,
                self.voltage_compliance_spin,
            )
            average_count = self.average_count_spin.value()
            units = (self.current_compliance_unit, self.voltage_compliance_unit)
            values = [spin.value() for spin in spins]
            unit_texts = [combo.currentText() for combo in units]
            if (
                self.measurement_settings_dialog.exec()
                != QtWidgets.QDialog.DialogCode.Accepted
            ):
                self.average_count_spin.setValue(average_count)
                for spin, value in zip(spins, values):
                    spin.setValue(value)
                for combo, text in zip(units, unit_texts):
                    combo.setCurrentText(text)

        def _meter_group(self):
            group = QtWidgets.QGroupBox("Meter")
            form = QtWidgets.QFormLayout(group)
            form.addRow("Device", self.meter_model_combo)
            form.addRow(
                "Resource",
                self._resource_row(
                    self.meter_resource_combo, self.meter_refresh_button
                ),
            )
            form.addRow("NPLC", self.nplc_spin)
            buttons = QtWidgets.QHBoxLayout()
            for button in (self.meter_connect_button, self.meter_disconnect_button):
                buttons.addWidget(button)
            form.addRow("", buttons)
            return group

        def _measurement_group(self):
            group = QtWidgets.QGroupBox("Measurement")
            layout = QtWidgets.QHBoxLayout(group)
            left = QtWidgets.QFormLayout()
            left.addRow("Mode", self.mode_combo)
            left.addRow("Sweep", self.sweep_combo)
            left.addRow(
                "Start", self._quantity_row(self.start_spin, self.start_unit_combo)
            )
            left.addRow("End", self._quantity_row(self.end_spin, self.end_unit_combo))
            left.addRow(
                "Step", self._quantity_row(self.step_spin, self.step_unit_combo)
            )
            left.addRow("", self.measurement_settings_button)

            right_widget = QtWidgets.QWidget()
            right = QtWidgets.QVBoxLayout(right_widget)
            right.setContentsMargins(0, 0, 0, 0)
            right.addWidget(self._output_group())
            right.addWidget(self._run_group())
            right.addStretch(1)

            layout.addLayout(left, 1)
            layout.addWidget(right_widget, 1)
            return group

        def _output_group(self):
            group = QtWidgets.QGroupBox("Output")
            form = QtWidgets.QFormLayout(group)
            form.addRow(
                "Directory",
                self._resource_row(self.output_dir_edit, self.output_browse_button),
            )
            form.addRow(
                "File",
                self._resource_row(self.output_name_edit, self.auto_suffix_check),
            )
            return group

        def _run_group(self):
            group = QtWidgets.QGroupBox("Run")
            layout = QtWidgets.QVBoxLayout(group)
            run_row = QtWidgets.QHBoxLayout()
            for button in (self.start_button, self.stop_button, self.output_off_button):
                run_row.addWidget(button)
            layout.addLayout(run_row)
            return group

        def _plot_status_bar(self):
            widget = QtWidgets.QWidget()
            layout = QtWidgets.QHBoxLayout(widget)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(QtWidgets.QLabel("Status"))
            layout.addWidget(self.status_label, 2)
            layout.addWidget(QtWidgets.QLabel("Point"))
            layout.addWidget(self.step_label, 1)
            layout.addWidget(QtWidgets.QLabel("Resistance"))
            layout.addWidget(self.resistance_label, 1)
            layout.addWidget(QtWidgets.QLabel("Conductance"))
            layout.addWidget(self.conductance_label, 1)
            return widget

        def _quantity_row(self, spin, unit):
            widget = QtWidgets.QWidget()
            layout = QtWidgets.QHBoxLayout(widget)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(spin, 1)
            layout.addWidget(unit)
            return widget

        def _resource_row(self, primary, button):
            widget = QtWidgets.QWidget()
            layout = QtWidgets.QHBoxLayout(widget)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(primary, 1)
            layout.addWidget(button)
            return widget

        def _spin(self, minimum: float, maximum: float, decimals: int, value: float):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(minimum, maximum)
            spin.setDecimals(3)
            spin.setValue(value)
            spin.setKeyboardTracking(False)
            spin.setButtonSymbols(QtWidgets.QAbstractSpinBox.ButtonSymbols.NoButtons)
            return spin

        def _source_key(self) -> str:
            source_ref, _ = self._active_refs(self.config)
            return source_ref.split(".", 1)[1]

        def _meter_key(self) -> str:
            _, meter_ref = self._active_refs(self.config)
            return meter_ref.split(".", 1)[1]

        def _sync_measurement_controls(self) -> None:
            controls_enabled = (
                self.measurement_state.controls_enabled
                and self.discovery_thread is None
                and not self.startup_busy
            )
            for widget in (
                self.config_path_edit,
                self.browse_button,
                self.load_button,
                self.save_button,
                self.connect_all_button,
                self.disconnect_all_button,
                self.source_model_combo,
                self.source_resource_combo,
                self.source_refresh_button,
                self.source_connect_button,
                self.source_disconnect_button,
                self.meter_model_combo,
                self.meter_resource_combo,
                self.meter_refresh_button,
                self.meter_connect_button,
                self.meter_disconnect_button,
                self.output_off_button,
                self.measurement_settings_button,
                self.current_compliance_spin,
                self.current_compliance_unit,
                self.voltage_compliance_spin,
                self.voltage_compliance_unit,
            ):
                widget.setEnabled(controls_enabled)
            self.start_button.setEnabled(controls_enabled)
            self.stop_button.setEnabled(self.measurement_state.can_stop)

        def _ensure_measurement_idle(self, action: str) -> bool:
            if self.startup_busy:
                self.append_log(f"{action} skipped: USB setup is running.")
                return False
            if self.discovery_thread is not None:
                self.append_log(f"{action} skipped: instrument discovery is running.")
                return False
            if not self.measurement_state.active:
                return True
            self.append_log(f"{action} skipped: measurement is running.")
            return False

        def _active_refs(self, config: dict[str, Any]) -> tuple[str, str]:
            mode = str(config["measurements"]["iv"].get("mode", "dc_iv"))
            role_key = "vi" if mode == "dc_vi" else "iv"
            role = config.get("roles", {}).get(role_key) or config["roles"]["iv"]
            return str(role["source"]), str(role["measure"])

        def _mode(self) -> str:
            return str(self.mode_combo.currentData() or "dc_vi")

        def _set_mode(self, mode: str) -> None:
            for index in range(self.mode_combo.count()):
                if self.mode_combo.itemData(index) == mode:
                    self.mode_combo.setCurrentIndex(index)
                    return

        def _mode_units(self, mode: str) -> list[str]:
            return CURRENT_UNITS if mode == "dc_vi" else VOLTAGE_UNITS

        def _default_unit(self, mode: str) -> str:
            return "mA" if mode == "dc_vi" else "mV"

        def _replace_units(
            self, combo, units: list[str], preferred: str | None = None
        ) -> None:
            current = preferred or combo.currentText()
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(units)
            index = combo.findText(current)
            combo.setCurrentIndex(index if index >= 0 else 0)
            combo.blockSignals(False)

        def _mode_changed(self) -> None:
            mode = self._mode()
            units = self._mode_units(mode)
            default_unit = self._default_unit(mode)
            for combo in (
                self.start_unit_combo,
                self.end_unit_combo,
                self.step_unit_combo,
            ):
                preferred = (
                    combo.currentText()
                    if combo.currentText() in units
                    else default_unit
                )
                self._replace_units(combo, units, preferred)
            self._refresh_plot_labels()

        def _meter_model_changed(self, model: str) -> None:
            _, cfg = _model_config_for_selection(self.config, "meter", model)
            if cfg is not None:
                self.meter_resource_combo.setCurrentText(str(cfg.get("resource", "")))

        def _source_model_changed(self, model: str) -> None:
            _, cfg = _model_config_for_selection(self.config, "source", model)
            if cfg is not None:
                self.source_resource_combo.setCurrentText(str(cfg.get("resource", "")))

        def _load_fields(self) -> None:
            settings = self.config["measurements"]["iv"]
            mode = str(settings.get("mode", "dc_vi"))
            self._set_mode(mode)
            self._mode_changed()

            safety = settings.get("safety", {})
            for key, family, spin, combo, default_unit in (
                (
                    "current_compliance",
                    "current",
                    self.current_compliance_spin,
                    self.current_compliance_unit,
                    "mA",
                ),
                (
                    "voltage_compliance",
                    "voltage",
                    self.voltage_compliance_spin,
                    self.voltage_compliance_unit,
                    "V",
                ),
            ):
                value, unit = _quantity_value(safety, key, 1.0, default_unit)
                legacy = safety.get("compliance", {})
                if key not in safety and isinstance(legacy, dict):
                    if _unit_family(str(legacy.get("unit", ""))) == family:
                        value, unit = _quantity_value(
                            safety, "compliance", 1.0, default_unit
                        )
                quantity = parse_quantity(
                    {"value": value, "unit": unit}, dimension=family
                )
                if combo.findText(unit) < 0:
                    value, unit = quantity.si_float, quantity.si_unit
                if (
                    not math.isfinite(value)
                    or not spin.minimum() <= value <= spin.maximum()
                ):
                    raise ValueError(
                        f"{key} is outside the GUI's positive input range."
                    )
                spin.setValue(value)
                combo.setCurrentText(unit)

            source_key = self._source_key()
            meter_key = self._meter_key()
            source = self.config["instruments"]["source"][source_key]
            meter = self.config["instruments"]["meter"][meter_key]
            self.source_model_combo.setCurrentText(
                str(source.get("model", SOURCE_MODELS[0])).upper()
            )
            self.source_resource_combo.setCurrentText(str(source.get("resource", "")))
            self.meter_model_combo.setCurrentText(
                str(meter.get("model", METER_MODELS[0])).upper()
            )
            self.meter_resource_combo.setCurrentText(str(meter.get("resource", "")))

            scan = settings["scan"]
            self.sweep_combo.setCurrentText(str(scan.get("pattern", "linear")))
            default_unit = self._default_unit(mode)
            for key, spin, scan_unit in (
                ("start", self.start_spin, self.start_unit_combo),
                ("stop", self.end_spin, self.end_unit_combo),
                ("step", self.step_spin, self.step_unit_combo),
            ):
                value, unit_text = _quantity_value(scan, key, 0.0, default_unit)
                spin.setValue(value)
                self._replace_units(scan_unit, self._mode_units(mode), unit_text)

            timing = settings.get("timing", {})
            self.wait_spin.setValue(float(timing.get("settle_s", 0.2)))
            self.average_count_spin.setValue(int(timing.get("average_count", 1)))
            self.nplc_spin.setValue(float(timing.get("nplc", 1.0)))
            output = settings.get("output", {})
            self.output_dir_edit.setText(str(output.get("dir", "results")))
            self.output_name_edit.setText(str(output.get("filename", "iv_run")))
            self.auto_suffix_check.setChecked(
                bool(output.get("auto_timestamp_suffix", True))
            )
            self._refresh_plot_labels()

        def _config_from_fields(self) -> dict[str, Any]:
            config = copy.deepcopy(self.config)
            source_key = self._source_key_for_selected_model(config)
            meter_key = self._meter_key_for_selected_model(config)
            source_model = (
                self.source_model_combo.currentText().strip().upper()
                or "YOKOGAWA_GS210"
            )
            meter_model = self.meter_model_combo.currentText().strip().upper()
            config["instruments"]["source"][source_key]["model"] = source_model
            config["instruments"]["source"][source_key]["resource"] = (
                self.source_resource_combo.currentText().strip()
            )
            config["instruments"]["meter"][meter_key]["model"] = meter_model
            config["instruments"]["meter"][meter_key]["resource"] = (
                self.meter_resource_combo.currentText().strip()
            )
            if meter_model == "ADCMT_7461A":
                config["instruments"]["meter"][meter_key].setdefault(
                    "command_language", "scpi"
                )
            for role_key in ("iv", "vi"):
                config["roles"].setdefault(role_key, {})
                config["roles"][role_key]["source"] = f"source.{source_key}"
                config["roles"][role_key]["measure"] = f"meter.{meter_key}"

            settings = config["measurements"]["iv"]
            mode = self._mode()
            settings["mode"] = mode
            scan = settings.setdefault("scan", {})
            scan["pattern"] = self.sweep_combo.currentText()
            _set_quantity(
                scan,
                "start",
                self.start_spin.value(),
                self.start_unit_combo.currentText(),
            )
            _set_quantity(
                scan, "stop", self.end_spin.value(), self.end_unit_combo.currentText()
            )
            _set_quantity(
                scan, "step", self.step_spin.value(), self.step_unit_combo.currentText()
            )
            scan.setdefault("repeat", 1)
            scan.setdefault("custom_points", [])

            timing = settings.setdefault("timing", {})
            timing["pre_delay_s"] = float(timing.get("pre_delay_s", 0.1))
            timing["start_settle_s"] = float(timing.get("start_settle_s", 0.5))
            timing["settle_s"] = self.wait_spin.value()
            timing["post_zero_delay_s"] = float(timing.get("post_zero_delay_s", 0.1))
            timing["ramp_step_wait_s"] = float(timing.get("ramp_step_wait_s", 0.02))
            timing["nplc"] = self.nplc_spin.value()
            timing["average_count"] = self.average_count_spin.value()
            timing["measure_timeout_s"] = float(timing.get("measure_timeout_s", 10.0))
            timing["timing_mode"] = "software"
            settings.setdefault("measure", {})["auto_range"] = True
            settings["output"] = {
                "dir": self.output_dir_edit.text().strip() or "results",
                "filename": self.output_name_edit.text().strip() or "iv_run",
                "auto_timestamp_suffix": self.auto_suffix_check.isChecked(),
            }

            safety = settings.setdefault("safety", {})
            source_unit = self.start_unit_combo.currentText()
            source_limit_value = max(
                abs(self.start_spin.value()), abs(self.end_spin.value())
            )
            _set_quantity(safety, "max_abs_source", source_limit_value, source_unit)
            _set_quantity(
                safety,
                "ramp_step",
                abs(self.step_spin.value()),
                self.step_unit_combo.currentText(),
            )
            _set_quantity(
                safety,
                "current_compliance",
                self.current_compliance_spin.value(),
                self.current_compliance_unit.currentText(),
            )
            _set_quantity(
                safety,
                "voltage_compliance",
                self.voltage_compliance_spin.value(),
                self.voltage_compliance_unit.currentText(),
            )
            active_limit = (
                "voltage_compliance" if mode == "dc_vi" else "current_compliance"
            )
            safety["compliance"] = copy.deepcopy(safety[active_limit])
            safety["stop_on_compliance"] = True
            safety["on_finish"] = "ramp_to_zero_then_off"
            safety["on_stop"] = "ramp_to_zero_then_off"
            safety["on_error"] = "output_off"
            safety["output_off_on_finish"] = True
            return config

        def _source_key_for_selected_model(self, config: dict[str, Any]) -> str:
            model = self.source_model_combo.currentText().strip().upper()
            current = self._source_key()
            key = _device_key_for_selection(config, "source", model, current)
            if key != current:
                return key
            config["instruments"].setdefault("source", {}).setdefault(current, {})
            return current

        def _meter_key_for_selected_model(self, config: dict[str, Any]) -> str:
            model = self.meter_model_combo.currentText().strip().upper()
            current = self._meter_key()
            key = _device_key_for_selection(config, "meter", model, current)
            if key != current:
                return key
            config["instruments"].setdefault("meter", {}).setdefault(current, {})
            return current

        def browse_config(self) -> None:
            if not self._ensure_measurement_idle("Browse Config"):
                return
            path, _ = QtWidgets.QFileDialog.getOpenFileName(
                self, "Load Config", str(Path.cwd()), "JSON Files (*.json)"
            )
            if path:
                self.config_path_edit.setText(path)

        def browse_output_dir(self) -> None:
            path = QtWidgets.QFileDialog.getExistingDirectory(
                self, "Output Directory", self.output_dir_edit.text() or str(Path.cwd())
            )
            if path:
                self.output_dir_edit.setText(path)

        def load_preset(self, path: str) -> None:
            self.config_path_edit.setText(str(Path(path)))
            self.load_config()

        def connect_all(self) -> None:
            if not self._ensure_measurement_idle("All Connect"):
                return
            self.connect_source()
            self.connect_meter()

        def disconnect_all(self) -> None:
            if not self._ensure_measurement_idle("All Disconnect"):
                return
            self._safe_zero_output_off(raise_errors=False)
            self.experiment.disconnect_all()
            self.source_status.setText("local")
            self.meter_status.setText("local")
            self.append_log("Disconnected all.")

        def load_config(self) -> None:
            if not self._ensure_measurement_idle("Load Config"):
                return
            try:
                self.config_path = Path(self.config_path_edit.text()).expanduser()
                self.config = load_config(self.config_path)
                self.experiment.config = self.config
                self._load_fields()
                write_last_config_path(self.config_path)
                self.append_log(f"Loaded config: {self.config_path}")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Config Error", str(e))
                self.append_log(f"Config error: {e}")

        def save_config(self) -> None:
            if not self._ensure_measurement_idle("Save Config"):
                return
            try:
                self.config = self._config_from_fields()
                self.config_path = save_config(
                    self.config, self.config_path_edit.text()
                )
                self.config_path_edit.setText(str(self.config_path))
                self.experiment.config = self.config
                write_last_config_path(self.config_path_edit.text())
                self.append_log(f"Saved config: {self.config_path_edit.text()}")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Config Error", str(e))
                self.append_log(f"Config error: {e}")

        def refresh_resources(self) -> None:
            if not self._ensure_measurement_idle("Refresh Resources"):
                return
            thread = QtCore.QThread(self)
            worker = ResourceDiscoveryWorker()
            self.discovery_thread = thread
            self.discovery_worker = worker
            worker.moveToThread(thread)
            thread.started.connect(worker.run)
            worker.progress.connect(self._discovery_progress)
            worker.discovered.connect(self._resources_discovered)
            worker.error_occurred.connect(self._resource_discovery_error)
            worker.finished.connect(thread.quit)
            worker.finished.connect(worker.deleteLater)
            thread.finished.connect(self._resource_discovery_finished)
            thread.finished.connect(thread.deleteLater)
            self.source_refresh_button.setText("Scanning...")
            self.meter_refresh_button.setText("Scanning...")
            self._sync_measurement_controls()
            self.append_log("Scanning connected instruments...")
            self.discovery_phase = "Checking connected instruments"
            self.discovery_previous_status = self.status_label.text()
            self.discovery_elapsed.start()
            self.discovery_timer.start(1000)
            self._update_discovery_status()
            thread.start()

        def _update_discovery_status(self) -> None:
            if self.discovery_thread is not None:
                self.status_label.setText(
                    f"Scanning: {self.discovery_phase} ({self.discovery_elapsed.elapsed() // 1000}s)"
                )

        def _discovery_progress(self, message: str) -> None:
            self.discovery_phase = message
            self.append_log(
                f"Scan [{self.discovery_elapsed.elapsed() // 1000}s]: {message}"
            )
            self._update_discovery_status()

        def _resources_discovered(self, found: tuple[str, ...]) -> None:
            resources = list(found)
            for combo in (self.source_resource_combo, self.meter_resource_combo):
                current = combo.currentText()
                combo.clear()
                choices = list(
                    dict.fromkeys([*resources, *([current] if current else [])])
                )
                combo.addItems(choices)
                if current:
                    combo.setCurrentText(current)
            self.append_log(f"Resources refreshed. Found {len(resources)} resource(s).")

        def _resource_discovery_error(self, message: str) -> None:
            QtWidgets.QMessageBox.warning(self, "Resource Error", message)
            self.append_log(f"Resource error: {message}")

        def _resource_discovery_finished(self) -> None:
            self.discovery_timer.stop()
            self.status_label.setText(self.discovery_previous_status)
            self.discovery_thread = None
            self.discovery_worker = None
            self.source_refresh_button.setText("Refresh")
            self.meter_refresh_button.setText("Refresh")
            self._sync_measurement_controls()

        def _apply_config(self) -> None:
            self.config = self._config_from_fields()
            self.experiment.config = self.config

        def connect_source(self) -> None:
            if not self._ensure_measurement_idle("Source Connect"):
                return
            try:
                self._apply_config()
                source_ref, _ = self._active_refs(self.config)
                source = self.experiment.connect_device(source_ref)
                idn = source.identify()
                source.output_off()
                source.set_level(0.0)
                source.output_off()
                self.source_status.setText(
                    f"{idn}\noutput={source.output_state()} level={_short(source.read_level())}"
                )
                self.append_log(f"Connected {source_ref}: {idn}")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Connect Error", str(e))
                self.source_status.setText("connection failed")
                self.append_log(f"Source connect error: {e}")

        def disconnect_source(self) -> None:
            if not self._ensure_measurement_idle("Source Disconnect"):
                return
            source_ref, _ = self._active_refs(self.config)
            self._safe_zero_output_off(raise_errors=False)
            affected = self.experiment.disconnect_device(source_ref)
            self._mark_disconnected(affected or [source_ref])
            self.append_log(f"Disconnected {', '.join(affected or [source_ref])}.")

        def connect_meter(self) -> None:
            if not self._ensure_measurement_idle("Meter Connect"):
                return
            try:
                self._apply_config()
                _, meter_ref = self._active_refs(self.config)
                meter = self.experiment.connect_device(meter_ref)
                idn = meter.identify()
                status = self._connect_status(meter)
                self.meter_status.setText(f"{idn}\n{status}")
                self.append_log(f"Connected {meter_ref}: {idn}")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Connect Error", str(e))
                self.meter_status.setText("connection failed")
                self.append_log(f"Meter connect error: {e}")

        def _connect_status(self, device) -> str:
            method = getattr(device, "connect_status", None)
            if method is not None:
                return str(method())
            try:
                device.write("*CLS")
                return str(device.query("SYST:ERR?"))
            except Exception as e:
                return f"status unavailable: {e}"

        def disconnect_meter(self) -> None:
            if not self._ensure_measurement_idle("Meter Disconnect"):
                return
            _, meter_ref = self._active_refs(self.config)
            affected = self.experiment.disconnect_device(meter_ref)
            self._mark_disconnected(affected or [meter_ref])
            self.append_log(f"Disconnected {', '.join(affected or [meter_ref])}.")

        def _mark_disconnected(self, refs: list[str]) -> None:
            if any(ref.startswith("source.") for ref in refs):
                self.source_status.setText("local")
            if any(ref.startswith("meter.") for ref in refs):
                self.meter_status.setText("local")

        def check_plan(self) -> None:
            try:
                config = self._config_from_fields()
                plan = iv_plan_from_config(config)
                path = output_path(config, "iv")
                self.status_label.setText(plan.summary)
                self.append_log(f"Check OK: {plan.summary} -> {path}")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Plan Error", str(e))
                self.append_log(f"Plan error: {e}")

        def start_measurement(self) -> None:
            if self.discovery_thread is not None:
                self.append_log("Start skipped: instrument discovery is running.")
                return
            if self.measurement_state.active:
                self.append_log("Start skipped: measurement is already running.")
                return
            try:
                self._apply_config()
                plan = iv_plan_from_config(self.config)
                source_ref, meter_ref = self._active_refs(self.config)
                connected = self.experiment.connected_devices()
                if not connected.get(source_ref) or not connected.get(meter_ref):
                    raise RuntimeError("Connect Source and Meter before starting.")
                out = output_path(self.config, "iv")
                self.rows.clear()
                self._update_plot()
                self.worker_thread = QtCore.QThread()
                self.worker = MeasurementWorker(
                    experiment=self.experiment, config=self.config, output=str(out)
                )
                self.worker.moveToThread(self.worker_thread)
                self.worker_thread.started.connect(self.worker.run)
                self.worker.status_changed.connect(self.handle_status)
                self.worker.point_ready.connect(self.handle_point)
                self.worker.error_occurred.connect(self.handle_error)
                self.worker.finished.connect(self.handle_finished)
                self.worker.finished.connect(self.worker_thread.quit)
                self.worker.finished.connect(self.worker.deleteLater)
                self.worker_thread.finished.connect(self._thread_finished)
                self.worker_thread.finished.connect(self.worker_thread.deleteLater)
                self.measurement_state.begin()
                self._sync_measurement_controls()
                self.worker_thread.start()
                self.append_log(f"Started {plan.summary} -> {out}")
            except Exception as e:
                self.measurement_state.reset()
                self._sync_measurement_controls()
                QtWidgets.QMessageBox.critical(self, "Start Error", str(e))
                self.append_log(f"Start error: {e}")

        def stop_measurement(self) -> None:
            if self.worker is not None and self.measurement_state.request_stop():
                self.worker.stop()
                self._sync_measurement_controls()
                self.append_log("Stop requested.")

        def output_off(self) -> None:
            if not self._ensure_measurement_idle("Output Off"):
                return
            try:
                self._apply_config()
                source = self._safe_zero_output_off(connect_if_missing=True)
                if source is None:
                    raise RuntimeError("Source is not available.")
                self.source_status.setText(
                    f"output=False level={_short(source.read_level())}"
                )
                self.append_log("Source output off and level set to zero.")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Output Off Error", str(e))
                self.append_log(f"Output off error: {e}")

        def _safe_zero_output_off(
            self, *, connect_if_missing: bool = False, raise_errors: bool = True
        ):
            try:
                source_ref, _ = self._active_refs(self.config)
                try:
                    source = self.experiment.session.require(source_ref)
                except RuntimeError:
                    if not connect_if_missing:
                        return None
                    source = self.experiment.connect_device(source_ref)
                source.output_off()
                source.set_level(0.0)
                source.output_off()
                return source
            except Exception as e:
                if raise_errors:
                    raise
                self.append_log(f"Output off/zero skipped: {e}")
                return None

        def handle_status(self, status: str) -> None:
            self.status_label.setText(status)
            self.append_log(status)

        def handle_error(self, message: str) -> None:
            self.measurement_state.record_error(message)
            self.append_log(f"Error: {message}")
            QtWidgets.QMessageBox.critical(self, "Measurement Error", message)

        def handle_point(self, point) -> None:
            row = point.row
            self.rows.append(row)
            self._update_plot()
            self._update_snapshot(row)

        def handle_finished(self, rows) -> None:
            self.measurement_state.finish(len(rows))
            self.append_log(f"Finished. {len(rows)} points collected.")
            self.status_label.setText(f"finished {len(rows)} points")
            self._sync_measurement_controls()
            self.append_log(
                "Source returned to zero/output off. Devices remain remote."
            )

        def _thread_finished(self) -> None:
            self.worker_thread = None
            self.worker = None

        def _refresh_plot_labels(self) -> None:
            mode = self._mode()
            if mode == "dc_vi":
                self.plot.setLabel("bottom", "Current", units="A")
                self.plot.setLabel("left", "Voltage", units="V")
            else:
                self.plot.setLabel("bottom", "Voltage", units="V")
                self.plot.setLabel("left", "Current", units="A")

        def _plot_points(self) -> list[tuple[float, float, str]]:
            mode = self._mode()
            points: list[tuple[float, float, str]] = []
            for row in self.rows:
                measured_v = row.get("measured_V")
                measured_a = row.get("measured_A")
                if measured_v is None or measured_a is None:
                    continue
                if mode == "dc_vi":
                    x, y = float(measured_a), float(measured_v)
                else:
                    x, y = float(measured_v), float(measured_a)
                points.append((x, y, str(row.get("direction") or "forward")))
            return points

        def _plot_groups(self) -> dict[str, list[tuple[float, float]]]:
            groups: dict[str, list[tuple[float, float]]] = {
                key: [] for key in self.plot_curves
            }
            last_point: tuple[float, float] | None = None
            last_direction: str | None = None
            for x, y, direction in self._plot_points():
                key = direction if direction in groups else "custom"
                if last_point is not None and key != last_direction:
                    if groups[key]:
                        groups[key].append((float("nan"), float("nan")))
                    groups[key].append(last_point)
                groups[key].append((x, y))
                last_point = (x, y)
                last_direction = key
            return groups

        def _update_plot(self) -> None:
            self._refresh_plot_labels()
            groups = self._plot_groups()
            count = len(self._plot_points())
            has_points = False
            for key, curve in self.plot_curves.items():
                points = groups.get(key, [])
                xs = [x for x, _ in points]
                ys = [y for _, y in points]
                curve.setData(xs, ys)
                has_points = has_points or bool(points)
            if has_points:
                self.plot.enableAutoRange(axis="xy", enable=True)
                self.plot.autoRange()
            resistance = _resistance_from_rows(self.rows)
            conductance = None if resistance in (None, 0) else 1.0 / resistance
            point_text = (
                f"{count}/{self.rows[-1].get('total_points', '-')}"
                if self.rows
                else "-"
            )
            resistance_text = format_resistance(resistance)
            conductance_text = format_conductance(conductance)
            self.step_label.setText(point_text)
            self.resistance_label.setText(resistance_text)
            self.conductance_label.setText(conductance_text)

        def _position_plot_text(self) -> None:
            if self.step_text is None or self.resistance_text is None:
                return
            view = self.plot.getViewBox().viewRange()
            x_min, x_max = view[0]
            y_min, y_max = view[1]
            self.step_text.setPos(x_min, y_max)
            self.resistance_text.setPos(x_max, y_max)

        def _update_snapshot(self, row: dict[str, Any]) -> None:
            keys = [key for key in SNAPSHOT_FIELDS if key in row]
            self.snapshot_table.setRowCount(len(keys))
            for index, key in enumerate(keys):
                self.snapshot_table.setItem(
                    index, 0, QtWidgets.QTableWidgetItem(str(key))
                )
                value = row.get(key)
                text = "" if value is None else _short(value)
                self.snapshot_table.setItem(index, 1, QtWidgets.QTableWidgetItem(text))
            self.snapshot_table.resizeColumnsToContents()

        def _toggle_snapshot(self) -> None:
            visible = self.snapshot_toggle.isChecked()
            self.snapshot_table.setVisible(visible)

        def _toggle_left_panel(self) -> None:
            visible = not self.left_panel_toggle.isChecked()
            self.left_content.setVisible(visible)
            self.left_panel_toggle.setText("<" if visible else ">")

        def _toggle_right_panel(self) -> None:
            visible = not self.right_panel_toggle.isChecked()
            self.right_content.setVisible(visible)
            self.right_panel_toggle.setText(">" if visible else "<")

        def append_log(self, text: str) -> None:
            self.log.appendPlainText(str(text))
            self.log.verticalScrollBar().setValue(
                self.log.verticalScrollBar().maximum()
            )

        def closeEvent(self, event) -> None:
            if self.startup_busy:
                self.append_log(
                    "Close delayed: USB setup is still running. Check Windows approval dialogs."
                )
                event.ignore()
                return
            if self.discovery_thread is not None:
                self.append_log("Close delayed: instrument discovery is still running.")
                event.ignore()
                return
            if self.worker is not None:
                self.worker.stop()
            if self.worker_thread is not None and self.worker_thread.isRunning():
                self.worker_thread.quit()
                if not self.worker_thread.wait(15000):
                    self.append_log(
                        "Close delayed: measurement thread is still stopping."
                    )
                    event.ignore()
                    return
            try:
                self._safe_zero_output_off(raise_errors=False)
                self.experiment.disconnect_all()
            finally:
                super().closeEvent(event)

    app = QtWidgets.QApplication(sys.argv)
    window = IVGui()
    window.show()
    if startup is not None:
        QtCore.QTimer.singleShot(0, lambda: startup(window))
    sys.exit(app.exec())


if __name__ == "__main__":  # pragma: no cover - GUI script calls main
    main()
