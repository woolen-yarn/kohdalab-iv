from pyvisa import constants

from kohdalab_iv.instruments.meters.adcmt_7461a import ADCMT7461A
from kohdalab_iv.instruments.meters.agilent_34401a import Agilent34401A
from kohdalab_iv.instruments.meters.keysight_34411a import Keysight34411A
from kohdalab_iv.instruments.sources.yokogawa_7651 import Yokogawa7651
from kohdalab_iv.instruments.visa_base import VisaDevice, _ni4882_set_ren


class FakeFunction:
    def __init__(self, callback):
        self.callback = callback
        self.argtypes = None
        self.restype = None

    def __call__(self, *args):
        return self.callback(*args)


class FakeNi4882Library:
    def __init__(self):
        self.calls = []
        self.ibfindA = FakeFunction(self._ibfind_a)
        self.ibconfig = FakeFunction(self._ibconfig)
        self.ibonl = FakeFunction(self._ibonl)

    def _ibfind_a(self, name):
        self.calls.append(("ibfindA", name))
        return 7

    def _ibconfig(self, ud, option, value):
        self.calls.append(("ibconfig", ud, option, value))
        return 0

    def _ibonl(self, ud, value):
        self.calls.append(("ibonl", ud, value))
        return 0


class FakeVisaLib:
    def __init__(self):
        self.gpib_commands = []

    def gpib_command(self, session, command):
        self.gpib_commands.append((session, command))


class FakeGPIBInterface:
    def __init__(self):
        self.commands = []
        self.ren_modes = []
        self.closed = False

    def send_command(self, command):
        self.commands.append(command)

    def control_ren(self, mode):
        self.ren_modes.append(mode)

    def close(self):
        self.closed = True


class FakeResourceManager:
    def __init__(self):
        self.opened_resources = []
        self.interface = FakeGPIBInterface()

    def open_resource(self, resource):
        self.opened_resources.append(resource)
        return self.interface


class FakeVisaHandle:
    def __init__(self):
        self.commands = []
        self.ren_modes = []
        self.usb_control_outs = []
        self.clear_count = 0
        self.query_responses = []
        self.read_responses = ["0"]
        self.session = object()
        self.invalid_session = False
        self.visalib = FakeVisaLib()
        self._resource_manager = FakeResourceManager()

    def write(self, command):
        self.commands.append(command)

    def query(self, command):
        self.commands.append(command)
        if self.query_responses:
            return self.query_responses.pop(0)
        return "0,No error"

    def clear(self):
        self.clear_count += 1

    def control_ren(self, mode):
        self.ren_modes.append(mode)

    def get_visa_attribute(self, attribute):
        if self.invalid_session and attribute == constants.VI_ATTR_RSRC_CLASS:
            raise RuntimeError("Invalid session handle")
        if attribute == constants.VI_ATTR_GPIB_PRIMARY_ADDR:
            return 26
        if attribute == constants.VI_ATTR_USB_INTFC_NUM:
            return 3
        return 3

    def control_out(self, request_type, request_id, request_value, index, data=b""):
        self.usb_control_outs.append(
            (request_type, request_id, request_value, index, data)
        )

    def read(self):
        return self.read_responses.pop(0)

    def close(self):
        self.session = None


def test_local_sends_scpi_local_and_gpib_gtl():
    handle = FakeVisaHandle()
    device = VisaDevice("GPIB0::1::INSTR", handle=handle)

    device.local()

    assert handle.commands == ["SYST:LOC"]
    assert handle.ren_modes == [constants.VI_GPIB_REN_ADDRESS_GTL]


def test_34401a_local_uses_gpib_gtl_without_scpi_system_local():
    handle = FakeVisaHandle()
    device = Agilent34401A("GPIB0::26::INSTR", handle=handle)

    device.local()

    assert handle.commands == []
    assert handle.ren_modes == [constants.VI_GPIB_REN_ADDRESS_GTL]


def test_34411a_local_uses_gpib_gtl_with_ren_release():
    handle = FakeVisaHandle()
    device = Keysight34411A("GPIB0::26::INSTR", handle=handle)

    device.local()

    assert handle.commands == []
    assert handle._resource_manager.opened_resources == ["GPIB0::INTFC"]
    assert handle._resource_manager.interface.commands == [
        bytes([0x3F, 0x20 + 26, 0x01, 0x3F]),
    ]
    assert handle._resource_manager.interface.ren_modes == [
        constants.VI_GPIB_REN_DEASSERT_GTL,
        constants.VI_GPIB_REN_DEASSERT,
    ]
    assert handle._resource_manager.interface.closed is True
    assert handle.visalib.gpib_commands == [
        (handle.session, bytes([0x3F, 0x20 + 26, 0x01, 0x3F])),
    ]
    assert handle.ren_modes == [
        constants.VI_GPIB_REN_ADDRESS_GTL,
        constants.VI_GPIB_REN_DEASSERT_GTL,
        constants.VI_GPIB_REN_DEASSERT,
    ]
    assert handle.usb_control_outs == [
        (0x21, 0xA1, 0, 3, b""),
        (0x21, 0xA0, 0, 3, b""),
    ]


def test_adcmt_7461a_configures_dc_voltage_and_reads_with_gpib_scpi_read():
    handle = FakeVisaHandle()
    handle.query_responses = ["0,No error"] * 4 + ["+1.234500E+00"]
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    device.configure_measurement(
        measure_function="dc_voltage", nplc=1.234, auto_range=True
    )
    value = device.read_once()

    assert handle.commands == [
        ":SYSTem:ERRor?",
        "*RST",
        ":SYSTem:ERRor?",
        ":SENSE:FUNCTION 'VOLTAGE:DC'",
        ":SYSTem:ERRor?",
        ":SENSE:VOLTAGE:DC:SRATE SSLOW",
        ":SYSTem:ERRor?",
        "READ?",
    ]
    assert value == 1.2345


def test_adcmt_7461a_usb_uses_adc_commands_even_when_configured_for_scpi():
    handle = FakeVisaHandle()
    handle.read_responses = ["+1.234500E+00"]
    device = ADCMT7461A("USB0::1::INSTR", handle=handle)
    device.READ_DELAY_S = 0

    device.configure_measurement(
        measure_function="dc_voltage", nplc=1.234, auto_range=True
    )
    value = device.read_once()

    assert handle.commands == [
        "*RST",
        "H0",
        "F1",
        "R0",
        "ITP1.234",
    ]
    assert value == 1.2345


def test_adcmt_7461a_usb_uses_adc_current_commands():
    handle = FakeVisaHandle()
    handle.read_responses = ["+1.234500E-06"]
    device = ADCMT7461A("USB0::1::INSTR", handle=handle)
    device.READ_DELAY_S = 0

    device.configure_measurement(
        measure_function="dc_current", nplc=1.0, auto_range=True
    )
    value = device.read_once()

    assert handle.commands == [
        "*RST",
        "H0",
        "F5",
        "R0",
        "ITP1",
    ]
    assert value == 1.2345e-6


def test_adcmt_7461a_configures_dc_current_without_auto_range_with_gpib_scpi():
    handle = FakeVisaHandle()
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    device.configure_measurement(
        measure_function="dc_current", nplc=1.0, auto_range=False
    )

    assert handle.commands == [
        ":SYSTem:ERRor?",
        "*RST",
        ":SYSTem:ERRor?",
        ":SENSE:FUNCTION 'CURRENT:DC'",
        ":SYSTem:ERRor?",
        ":SENSE:CURRENT:DC:SRATE SLOW",
        ":SYSTem:ERRor?",
    ]


def test_adcmt_7461a_can_use_adc_command_language_when_configured():
    handle = FakeVisaHandle()
    handle.read_responses = ["+1.234500E+00"]
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle, command_language="adc")
    device.READ_DELAY_S = 0

    device.configure_measurement(
        measure_function="dc_voltage", nplc=1.234, auto_range=True
    )
    value = device.read_once()

    assert handle.commands == [
        "*RST",
        "H0",
        "F1",
        "R0",
        "ITP1.234",
    ]
    assert value == 1.2345


def test_adcmt_7461a_rejects_unexpected_measurement_response():
    handle = FakeVisaHandle()
    handle.query_responses = ["ERR"]
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    try:
        device.read_once()
    except RuntimeError as e:
        message = str(e)
    else:
        raise AssertionError("Expected ADCMT response error")

    assert "Unexpected numeric response" in message
    assert "ERR" in message


def test_adcmt_7461a_discards_first_reading_after_settle():
    handle = FakeVisaHandle()
    handle.query_responses = ["0.0", "1.2345"]
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    device.prepare_for_reading()
    value = device.read_once()

    assert value == 1.2345
    assert handle.commands == ["READ?", "READ?"]


def test_adcmt_7461a_usb_discards_first_adc_reading_after_settle():
    handle = FakeVisaHandle()
    handle.read_responses = ["0.0", "1.2345"]
    device = ADCMT7461A("USB0::1::INSTR", handle=handle)
    device.READ_DELAY_S = 0

    device.configure_measurement(measure_function="dc_voltage", nplc=1.0)
    device.prepare_for_reading()
    value = device.read_once()

    assert value == 1.2345
    assert handle.commands == ["*RST", "H0", "F1", "R0", "ITP1"]


def test_adcmt_7461a_usb_connect_status_uses_adc_error_query():
    handle = FakeVisaHandle()
    handle.query_responses = ["0,No error"]
    device = ADCMT7461A("USB0::1::INSTR", handle=handle)
    device.USB_QUERY_DELAY_S = 0

    status = device.connect_status()

    assert status == "0,No error"
    assert handle.commands == ["*CLS", "ERR?"]


def test_adcmt_7461a_gpib_connect_status_uses_scpi_error_query():
    handle = FakeVisaHandle()
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    status = device.connect_status()

    assert status == "0,No error"
    assert handle.commands == ["*CLS", ":SYSTem:ERRor?"]


def test_adcmt_7461a_connect_status_drains_stale_undefined_header():
    handle = FakeVisaHandle()
    handle.query_responses = ["-113,Undefined header", "0,No error"]
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    status = device.connect_status()

    assert status == "0,No error"
    assert handle.commands == ["*CLS", ":SYSTem:ERRor?", ":SYSTem:ERRor?"]


def test_adcmt_7461a_connect_status_uses_adc_error_query_when_configured():
    handle = FakeVisaHandle()
    device = ADCMT7461A("USB0::1::INSTR", handle=handle, command_language="adc")
    device.USB_QUERY_DELAY_S = 0

    status = device.connect_status()

    assert status == "0,No error"
    assert handle.commands == ["*CLS", "ERR?"]


def test_adcmt_7461a_scpi_syncs_after_setting_commands():
    handle = FakeVisaHandle()
    handle.query_responses = ["0,No error"] * 4
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    device.configure_measurement(
        measure_function="dc_voltage", nplc=0.2, auto_range=True
    )

    assert handle.commands == [
        ":SYSTem:ERRor?",
        "*RST",
        ":SYSTem:ERRor?",
        ":SENSE:FUNCTION 'VOLTAGE:DC'",
        ":SYSTem:ERRor?",
        ":SENSE:VOLTAGE:DC:SRATE MED",
        ":SYSTem:ERRor?",
    ]


def test_adcmt_7461a_local_aborts_pending_scpi_measurement_before_addressed_gtl():
    handle = FakeVisaHandle()
    device = ADCMT7461A("GPIB0::27::INSTR", handle=handle)

    device.local()

    assert handle.clear_count == 1
    assert handle.commands[:4] == [":ABORt", ":SYSTem:ERRor?", "*CLS", ":SYSTem:ERRor?"]
    assert handle._resource_manager.opened_resources == []
    assert handle.visalib.gpib_commands == [
        (handle.session, bytes([0x3F, 0x20 + 26, 0x01, 0x3F])),
    ]
    assert handle.ren_modes == [constants.VI_GPIB_REN_ADDRESS_GTL]


def test_yokogawa_7651_configures_voltage_source_with_current_limit():
    handle = FakeVisaHandle()
    device = Yokogawa7651("GPIB0::1::INSTR", handle=handle)

    device.configure_source(
        source_function="voltage", source_range=4, hardware_compliance=0.01
    )

    assert handle.commands == ["H0;E", "F1;E", "R4;E", "LA10;E", "S0;E"]


def test_yokogawa_7651_configures_current_source_with_voltage_limit():
    handle = FakeVisaHandle()
    device = Yokogawa7651("GPIB0::1::INSTR", handle=handle)

    device.configure_source(
        source_function="current", source_range=5, hardware_compliance=3.0
    )

    assert handle.commands == ["H0;E", "F5;E", "R5;E", "LV3;E", "S0;E"]


def test_yokogawa_7651_output_control_and_readback():
    handle = FakeVisaHandle()
    handle.query_responses = ["STS1=16", "+1.234E-3"]
    device = Yokogawa7651("GPIB0::1::INSTR", handle=handle)

    device.output_on()
    assert device.output_state() is True
    value = device.read_level()
    device.output_off()

    assert value == 1.234e-3
    assert handle.commands == ["O1;E", "OC;E", "OD;E", "O0;E"]


def test_yokogawa_7651_local_uses_gpib_gtl_without_scpi_system_local():
    handle = FakeVisaHandle()
    device = Yokogawa7651("GPIB0::1::INSTR", handle=handle)

    device.local()

    assert handle.commands == []
    assert handle.ren_modes == [constants.VI_GPIB_REN_ADDRESS_GTL]


def test_visa_device_is_connected_detects_closed_handle():
    handle = FakeVisaHandle()
    device = VisaDevice("GPIB0::26::INSTR", handle=handle)

    assert device.is_connected() is True
    handle.close()

    assert device.is_connected() is False


def test_visa_device_is_connected_detects_invalid_session_handle():
    handle = FakeVisaHandle()
    device = VisaDevice("GPIB0::26::INSTR", handle=handle)

    handle.invalid_session = True

    assert device.is_connected() is False


def test_ni4882_set_ren_deasserts_ren_and_closes_board_handle():
    library = FakeNi4882Library()

    result = _ni4882_set_ren("GPIB0", False, loader=lambda _name: library)

    assert result is True
    assert library.calls == [
        ("ibfindA", b"gpib0"),
        ("ibconfig", 7, 0x000B, 0),
        ("ibonl", 7, 0),
    ]
