KohdaLab IV 0.2.3 - macOS Release Builder

Extract the entire ZIP on an Apple Silicon Mac. Install Xcode Command
Line Tools (xcode-select --install) and uv (https://docs.astral.sh/uv/).
Double-click Build-macOS.command, or run bash Build-macOS.command.
The final ZIP and checksum are created in project/dist/distribution.
A build log is saved in project/build/macos-portable-build.log.

The kit supplies native dependency sources and all rebuild scripts.
Internet access is needed for the locked Python dependencies.
Users of the finished portable do not need Python, uv or VISA.
The application is ad-hoc signed; Apple notarization is not included.
See project/docs/portable_release.md for supported connections.
