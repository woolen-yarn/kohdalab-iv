#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/project"
bash scripts/build_macos_portable.command
